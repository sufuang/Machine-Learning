
NODE_ADDRESS = 'http://127.0.0.1:8000'
INITIATED = 'initiated'
ACTED = 'acted'
TRACKED = 'tracked'

# user roles
SUPPLIER = 'Supplier'
RETAILER = 'Retailer'
COURIER = 'Courier'
